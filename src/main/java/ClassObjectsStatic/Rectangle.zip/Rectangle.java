package ClassObjectsStatic;

import java.util.Scanner;

public class Rectangle {
    int width;
    int height;

    public void calculateArea() {
        System.out.println("The area of the rectangle is : " + (width * height));
    }

    public void calculatePerimeter() {
        System.out.println("The Perimeter of the rectangle is : " + (width + height) * 2);
    }

}





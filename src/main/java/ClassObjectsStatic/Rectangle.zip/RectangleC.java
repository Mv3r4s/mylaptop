package ClassObjectsStatic;

import java.util.Scanner;

public class RectangleC {
    public static void main(String[] args) {

        Rectangle rect = new Rectangle();
        rect.height = 10;
        rect.width = 5;
        rect.calculateArea();
        rect.calculatePerimeter();

    }

}
